Locales['en'] = {
    ['robbed_too_recently'] = "You've robbed too recently.",
    ['target_dead']         = "The guy you're robbing is dead.",
    ['target_too_far']      = "Target is too far away.",
    ['robbery_started']     = "Robbery in progress!",
    ['robbery_completed']   = "You got ~g~%s~s~!",
    ['can_rob_again']       = "You can rob again!",
    ['remained'] = 'Remained~b~ ',
}