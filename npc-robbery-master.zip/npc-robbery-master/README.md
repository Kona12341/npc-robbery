# npc-robbery

Allows player to rob predestrians using 'E'
I cant take full credit for this, the code for robbing a player was taken from https://forum.cfx.re/t/release-esx-rob-npcs/166498

# V2
Now allows a user to rob items from a ped, items need to be added to the DB and configured in the config file

# Dependencies
[Progress Bars 1.0 [STANDALONE]]
https://forum.cfx.re/t/release-progress-bars-1-0-standalone/526287


